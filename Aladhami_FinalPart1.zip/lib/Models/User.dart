class User {
  String Username;
  String Password;
  String Email;
  String AuthLevel;

  User(this.Username, this.Password, this.Email, this.AuthLevel);
}
