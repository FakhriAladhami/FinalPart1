class AuthResponse {
  String userId;
  String token;

  AuthResponse(this.userId, this.token);
}
