class LoginStructure {
  String username;
  String password;

  LoginStructure(this.username, this.password);
}
