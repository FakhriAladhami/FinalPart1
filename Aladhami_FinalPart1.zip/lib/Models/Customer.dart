class Customer {
  String FirstName;
  String LastName;
  String PhoneNumber;
  String Address1;
  String Address2;
  String City;
  String State;
  String Email;

  Customer(this.FirstName, this.LastName, this.PhoneNumber, this.Address1,
      this.Address2, this.City, this.State, this.Email);
}
